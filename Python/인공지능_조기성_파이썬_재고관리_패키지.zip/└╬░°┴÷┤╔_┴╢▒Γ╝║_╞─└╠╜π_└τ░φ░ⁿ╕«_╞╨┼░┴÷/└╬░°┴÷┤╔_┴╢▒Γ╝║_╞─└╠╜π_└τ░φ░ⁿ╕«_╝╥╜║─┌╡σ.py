'''
물류창고 재고관리 프로그램

패키지화를 계획했으나 시간 부족으로 구현하지 못했습니다.

주요기능
0. 키
    관리자 키 및 일반 키 가 있으며 0000이 관리자 키
    관리자 키 입력 시 모든 기능 이용 가능
    일반 키(0000이외의 모든 값) 입력 시 조회만 가능, 종료

1. 재고관리
    csv파일에 리스트형식으로 저장가능
    불러와서 목록 확인 가능
    
2. 로그확인 시
    메모로그 저장 및 확인 가능
    현재까지의 메모로그 자동으로 띄워줌

3. 저장과 종료
    현재 수정한 자료 저장 및 sys를 사용한 콘솔종료가

4. 멀티스레딩 사용으로 시간 지날 시 자동 로그아웃 실행
    미구현!!!

'''
import csv
import sys
import time
import threading

class Storage :
    menu1 = 0
    menu2_1 = 0
    logwrite = 0
    storage = []
    storage_save = []
    storage_no = None
    

    def __init__(self) :
        self.input_data = open("C:/Users/moble/Desktop/인공지능_조기성_파이썬_재고관리_패키지/box.csv",'r')
        while True:
            line = self.input_data.readline()
            if not line: break
            self.storage.append(line)
        self.input_data.close()
        for i in range(0, len(self.storage)) :
            Storage.storage_no = self.storage[i].split('/')
            Storage.storage_save.append(self.storage_no)

    def view(self) :
        self.input_data = open("C:/Users/moble/Desktop/인공지능_조기성_파이썬_재고관리_패키지/box.csv",'r')
        while True :
            line = self.input_data.readline()
            if not line: break
            print(line)

    def update(self) :
        Storage.value = input("제품번호/제품명/제품가격/제품수량을 입력해주세요.\n")
        Storage.storage.append(self.value)
        Storage.storage_no = self.storage[4].split('/')
        Storage.storage_save.append(self.storage_no)
        print(self.storage_save)

    def log(self) :
        print("원하시는 기능의 숫자를 입력해주세요.\n")
        menu2_1 = int(input("-----1.메모로그추가-----2.종료-----\n"))
        if menu2_1 == 1 :
            print("현재까지의 모든 메모로그입니다.\n")
            f = open("C:/Users/moble/Desktop/인공지능_조기성_파이썬_재고관리_패키지/log.txt",'r')
            memo = f.read()
            f.close()
            f = open("C:/Users/moble/Desktop/인공지능_조기성_파이썬_재고관리_패키지/log.txt",'a')
            logwrite = input("추가할 메모를 입력해주세요.\n")
            f.write("\n" +logwrite + "\n")
            f.close()
            f = open("C:/Users/cgs07/Desktop/인공지능_조기성_파이썬_재고관리_패키지/log.txt",'r')
            memo = f.read()
            f.close()
            print(memo)

    #def time_in(self) :
        #global time_in
        #timein = threading.Timer(5,self,time).start()
        #if timein == True :
            #print("보안을 위해 10초 후 로그아웃됩니다.\n")
        #else :
            #pass

    #def time_out(self) :
        #global time_out
        #timeout = threading.Timer(6,self,time).start()
        #if timeout == True :
            #print("보안을 위해 로그아웃됩니다.\n")
        #else :
            #pass

    def save_and_exit(self) :
        print("이용해주셔서 감사합니다.\n")
        with open('C:/Users/moble/Desktop/인공지능_조기성_파이썬_재고관리_패키지/box.csv','w',newline='')as f:
            save_point = csv.writer(f)
            for i in self.storage_save :
                save_point.writerow(i)  
        sys.exit()

    def Main(self) :
        control_key = "0000"
        #self.time_in()
        #self.time_out()
        
        print("안녕하십니까? 물류창고 관리 프로그램 입니다.\n")
        key = input("관리자 키 또는 일반 키를 입력해주세요.\n")
        if (key == control_key) :
            while True :
                    print("원하시는 기능의 숫자를 입력해주세요.\n")
                    menu1 = int(input("-----1.목록조회-----2.제품등록-----3.메모로그메뉴-----4.저장 및 종료-----\n"))

                    if menu1 == 1 :
                        print("현재까지의 모든 메모로그입니다.\n")
                        f = open("C:/Users/moble/Desktop/인공지능_조기성_파이썬_재고관리_패키지/log.txt",'r')
                        memo = f.read()
                        f.close()
                        print("목록조회 결과입니다.\n")
                        self.view()
                        
                    elif menu1 == 2 :
                        print("제품등록 메뉴입니다.\n")
                        self.update()

                    elif menu1 == 3 :
                        print("로그메뉴 입니다.\n")
                        self.log()
                    
                    elif menu1 == 4 :
                        print("저장 및 종료를 실시합니다.\n")
                        self.save_and_exit()
                        
                    else :
                        print("잘못된 입력입니다. 원하시는 기능의 숫자를 입력해주세요.\n")

        else :
            print("일반 키로는 조회만 가능합니다.\n")
            self.view()
            sys.exit()
        

run = Storage()
run.Main()
