'''
무한루프를 사용하는 방법
    1. 변수를 통해서 무한루프
'''
'''
자판기
    돈 입력
    5000원을 넣었을때 구매할 수 있는 제품 활성화
    커피 100 음료수 500 과자 1000 아이스크림 600
    돈 부족 시 돈을 더 넣어라
    뽑을 시 계속 뽑으시겠습니까 or 끝내기
    결과 출력
    커피 5개 거스름돈 얼마
    개수
    관리자 페이지
    
'''
money = 0
question = 0
pro = 0
promenu = 0
proplus = 0
baguni = []
menu = {'커피':100, '음료수':500, '과자':1000, '아이스크림':600}

while True:
    money = int(money) + int(input('자판기입니다. 돈을 넣어주세요.'))
    print('총', money, '원 받았습니다')
    if money < menu['커피'] :
        print('살 수 있는게 없습니다. 돈을 더주세요.')
        continue
    elif money >= 100 and money < 500 :
        print('커피만 구매하실 수 있습니다.')
        question = input('구매하시겠습니까? y/n')
        if question == 'y' :
            money = money - 100
            baguni.insert(0, '커피')
            print ('장바구니에 담았습니다. 장바구니에', baguni,'가 있습니다.')
            print ('계속 주문하시겠습니까? y/n')
            if question == 'y' :
                continue
            else :
                print ('구매하신 물품',baguni,'와 거스름돈',money, '드리겠습니다. 감사합니다.')
                break
        else :
            print ('잔돈', money, '원 거슬러드렸습니다')
            break
        
    elif money >= 100 and money < 600 :
        print('커피, 음료수만 구매하실 수 있습니다.')
        question = input('어떤 물품을 구매하시겠습니까?')
        if question == '커피' :
            money = money - 100
            baguni.insert(0, '커피')
            print ('장바구니에 담았습니다. 장바구니에', baguni,'가 있습니다.')
            question = input('계속 주문하시겠습니까? y/n')
            if question == 'y' :
                continue
            else :
                print ('구매하신 물품',baguni,'와 거스름돈',money, '드리겠습니다. 감사합니다.')
                break
        elif question == '음료수' :
            money = money - 500
            baguni.insert(0, '음료수')
            print ('장바구니에 담았습니다. 장바구니에', baguni,'가 있습니다.')
            question = input('계속 주문하시겠습니까? y/n')
            if question == 'y' :
                continue
            else:
                print ('구매하신 물품',baguni,'와 거스름돈',money, '드리겠습니다. 감사합니다.')
                break
        else :
            print ('잔돈', money, '원 거슬러드렸습니다')
            break

    elif money >= 100 and money < 1000 :
        print('커피, 음료수, 아이스크림만 구매하실 수 있습니다.')
        question = input('어떤 물품을 구매하시겠습니까?')
        if question == '커피' :
            money = money - 100
            baguni.insert(0, '커피')
            print ('장바구니에 담았습니다. 장바구니에', baguni,'가 있습니다.')
            question = input('계속 주문하시겠습니까? y/n')
            if question == 'y' :
                continue
            else :
                print ('구매하신 물품',baguni,'와 거스름돈',money, '드리겠습니다. 감사합니다.')
                break
        elif question == '음료수' :
            money = money - 500
            baguni.insert(0, '음료수')
            print ('장바구니에 담았습니다. 장바구니에', baguni,'가 있습니다.')
            question = input('계속 주문하시겠습니까? y/n')
            if question == 'y' :
                continue
            else:
                print ('구매하신 물품',baguni,'와 거스름돈',money, '드리겠습니다. 감사합니다.')
                break
        elif question == '아이스크림' :
            money = money - 600
            baguni.insert(0, '아이스크림')
            print ('장바구니에 담았습니다. 장바구니에', baguni,'가 있습니다.')
            question = input('계속 주문하시겠습니까? y/n')
            if question == 'y' :
                continue
            else:
                print ('구매하신 물품',baguni,'와 거스름돈',money, '드리겠습니다. 감사합니다.')
                break
        else :
            print ('잔돈', money, '원 거슬러드렸습니다')
            break

    elif money >= 100 and money >= 1000 :
        print('커피, 음료수, 아이스크림, 과자 전부 구매하실 수 있습니다.')
        question = input('어떤 물품을 구매하시겠습니까?')
        if question == '커피' :
            money = money - 100
            baguni.insert(0, '커피')
            print ('장바구니에 담았습니다. 장바구니에', baguni,'가 있습니다.')
            question = input('계속 주문하시겠습니까? y/n')
            if question == 'y' :
                continue
            else :
                print ('구매하신 물품',baguni,'와 거스름돈',money, '드리겠습니다. 감사합니다.')
                break
        elif question == '음료수' :
            money = money - 500
            baguni.insert(0, '음료수')
            print ('장바구니에 담았습니다. 장바구니에', baguni,'가 있습니다.')
            question = input('계속 주문하시겠습니까? y/n')
            if question == 'y' :
                continue
            else:
                print ('구매하신 물품',baguni,'와 거스름돈',money, '드리겠습니다. 감사합니다.')
                break
        elif question == '아이스크림' :
            money = money - 600
            baguni.insert(0, '아이스크림')
            print ('장바구니에 담았습니다. 장바구니에', baguni,'가 있습니다.')
            question = input('계속 주문하시겠습니까? y/n')
            if question == 'y' :
                continue
            else:
                print ('잔돈', money, '원 거슬러드렸습니다')
                break
        elif question == '과자' :
            money = money - 1000
            baguni.insert(0, '과자')
            print ('장바구니에 담았습니다. 장바구니에', baguni,'가 있습니다.')
            question = input('계속 주문하시겠습니까? y/n')
            if question == 'y' :
                continue
            else:
                print ('구매하신 물품',baguni,'와 거스름돈',money, '드리겠습니다. 감사합니다.')
                break
        else :
            print ('잔돈', money, '원 거슬러드렸습니다.')
            break
    
    break
'''
while True:
    pro = input('관리자 모드를 원하신다면 p 를 눌러주세요')
    if pro == 'p' :
        int(input('메뉴를 추가하시려면 1, 삭제하시려면 2, 수량을 추가하시려면 3을 입력해주세요.'))
        if promenu == 1 :
            break
        elif promenu == 2 :
            break
        elif promenu == 3 :
            break
        else :
            print('초기메뉴로 돌아갑니다.')
            break
    else :
        break
'''
